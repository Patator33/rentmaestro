# Handoff : Portail Locataire RentMaestro (refonte)

## Overview
Refonte de l'espace locataire (portail à lien unique par locataire) : moins dense, hiérarchie visuelle plus claire, statut de paiement visible, raccourcis rapides, historique des loyers groupé par année, et navigation en pages dédiées (Accueil / Paiements / Incidents / Messages / Documents) avec une page d'accueil qui résume ce qui nécessite une action.

## About the Design Files
Les fichiers de ce bundle sont des **références de design en HTML** (prototype fonctionnel côté front, sans backend réel) — pas du code à copier tel quel dans l'app de production. La tâche : recréer fidèlement ce design dans l'environnement existant de l'app (a priori Node/React ou équivalent, à confirmer selon la stack réelle du repo GitHub), en branchant les vraies données (Prisma/DB existante) à la place des données statiques codées en dur dans le prototype.

## Fidelity
**Haute fidélité (hifi)** : couleurs, typographies, espacements et interactions ci-dessous sont définitifs. Le développeur doit recréer l'UI au pixel près avec les librairies/patterns déjà utilisés dans le codebase (composants, CSS-in-JS, Tailwind, etc. — à adapter au stack réel).

## Écrans / Pages
Le portail est un router client à 5 pages, toutes partageant une barre de nav en haut et une sidebar persistante (profil + logement + raccourcis).

### 1. Accueil
- **But** : donner en un coup d'œil ce qui nécessite une action.
- **Layout** : sidebar (300px) + contenu principal (flex 1). Contenu = titre "Aperçu" + grille de "cellules" (`grid-template-columns: repeat(auto-fit, minmax(220px,1fr))`, gap 12px).
- **Cellules conditionnelles** (n'apparaissent QUE si l'état est actif) :
  - Message non lu → icône message, titre "Nouveau message", sous-titre = aperçu du texte, clic → page Messages (marque comme lu).
  - Nouveau document → icône dossier, titre "Nouveau document", sous-titre = nom du fichier, clic → page Documents (retire le badge "Nouveau").
  - Incident en cours → même pattern, apparaît seulement s'il existe un incident ouvert (aucun exemple actuellement, mais le composant "cellule" est générique et prêt à recevoir ce cas).
- Si aucune cellule active : message discret "Rien à signaler…".
- Un point rouge (6px, couleur accent secondaire) apparaît à côté des items de nav "Messages"/"Documents" tant qu'il y a du nouveau.

### 2. Paiements
- Titre "Historique des loyers".
- Groupé par année dans un `<details>`/accordéon (année courante ouverte par défaut, années précédentes repliées, avec sous-titre "12 mois · 6 120,00 €").
- Table par groupe : colonnes Mois / Montant / Statut (tag "Payé") / bouton téléchargement (lien direct vers l'API de quittance existante).

### 3. Incidents
- État vide actuel : "Aucun incident signalé." + bouton "Signaler un incident" dans une card.
- (Le formulaire de signalement réel doit réutiliser celui déjà existant dans l'app — non redessiné ici.)

### 4. Messages
- Fil de messages (bulles) : messages du propriétaire alignés à gauche, messages du locataire alignés à droite (fond teinté accent, `max-width: 78%`, `margin-left: auto`).
- Barre de réponse en bas : input texte + bouton "Envoyer" (Entrée = envoi).

### 5. Documents
- Bouton "Ajouter un document" en haut à droite du titre (input file caché, déclenché par un `<label htmlFor>`).
- Fichiers envoyés par le locataire apparaissent dans un groupe "Vos documents envoyés" en tête de liste.
- Documents existants groupés par catégorie (Bail, Propriétaire, Généraux), chaque ligne : icône fichier, nom (troncature `text-overflow: ellipsis`), tag catégorie, bouton téléchargement (lien direct vers l'API fichier existante).
- Badge "Nouveau" (fond accent secondaire clair) sur le document marqué comme récent.

## Interactions & Behavior
- **Navigation** : état `page` en mémoire (pas de vraie route/URL dans le prototype — à brancher sur le routeur réel de l'app, ex. React Router, avec une route par section).
- **Accordéon paiements** : un seul groupe ouvert à la fois (toggle au clic sur l'en-tête, chevron qui tourne 180° avec `transition: transform .15s`).
- **Thème clair/sombre** : bouton pilule en haut à droite de la nav, bascule l'ensemble des tokens de couleur/typo (voir Design Tokens). Persistance non implémentée dans le prototype — à sauvegarder en `localStorage` ou préférence utilisateur côté back.
- **Hover** : nav links → couleur accent ; boutons → légère teinte accent ; cellules → ombre/liseré accent.
- **Upload** : `<input type="file" multiple>` — dans le prototype, ajoute juste le nom du fichier à une liste locale (pas d'upload réel). À brancher sur l'endpoint d'upload existant du backend.
- **Responsive** : layout en `display:flex; flex-wrap:wrap` (sidebar `flex: 1 1 280px`, contenu `flex: 3 1 480px`) → passe automatiquement en une colonne sur mobile. La nav est aussi `flex-wrap: wrap` pour éviter le débordement horizontal sur petit écran.

## State Management
- `theme`: 'light' | 'dark'
- `page`: 'accueil' | 'paiements' | 'incidents' | 'messages' | 'documents'
- `openYear`: année actuellement dépliée dans l'accordéon paiements
- `unreadMessage`: boolean (à remplacer par la vraie donnée "message non lu" du backend)
- `newDocId`: id du document marqué "nouveau" (à remplacer par un vrai flag "uploadedAt récent" côté backend)
- `draft`: texte en cours de saisie dans la messagerie
- `sent`: messages envoyés localement dans la session (à remplacer par un vrai appel API + websocket/polling)
- `uploaded`: fichiers sélectionnés localement en attente d'upload réel

## Design Tokens

### Thème clair (inspiré presse/serif)
- bg `#f3f2f2`, surface `#eae9e9`, texte `#201e1d`, texte atténué `rgba(32,30,29,0.62)`
- accent (interactif) `#0088b0`, accent foncé (texte sur fond teinté) `#006786`
- accent secondaire (badges "nouveau") `#d6006c`, foncé `#aa0b56`
- séparateurs `rgba(32,30,29,0.14)`
- police : "Source Serif 4" (titres et corps), poids titres 600, texte de message en italique
- rayons : 2 / 3 / 6px ; ombre légère `0 1px 2px rgba(45,43,43,0.12)`

### Thème sombre (inspiré interface compacte)
- bg `#161826`, surface `#232532`, texte `#e9e9ed`, texte atténué `rgba(233,233,237,0.6)`
- accent (bleu-violet, boutons primaires en contour et non en fond plein) `#9184d9`
- accent secondaire `#a7a1db`
- séparateurs `rgba(233,233,237,0.14)`
- police : "Inter", poids titres 500
- rayons : 4 / 8 / 14px ; séparateur de sections en dégradé qui s'estompe sur les bords (`linear-gradient` transparent → couleur → transparent)

### Typo (tailles)
h1 30px, h2 21px, corps 14–14.5px, meta/labels 11–12.5px.

## Assets
Aucune image — uniquement des icônes en SVG trait (paths inline, style outline 1.75px), dessinées à la main dans le prototype (maison, carte, alerte, message, dossier, téléchargement, envoi, fichier, upload, soleil/lune pour le toggle). À remplacer par la librairie d'icônes déjà utilisée dans l'app si elle existe (Lucide, Phosphor, etc.) en gardant les mêmes usages.

## Files
- `Portail Locataire - Final.html` — le prototype complet (thème clair/sombre, 5 pages, toutes les interactions ci-dessus). C'est la référence principale.
